<?php
include "adminheader.php";
include "adminsidebar.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body align="center">
    <p><h2>Welcome Admin!</h2></p>
	<div></div>

</body>
</html>