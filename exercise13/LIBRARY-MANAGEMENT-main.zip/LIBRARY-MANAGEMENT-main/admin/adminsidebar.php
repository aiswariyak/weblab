
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link href="../style.css" rel="stylesheet">

</head>
<body>
<!-- The sidebar -->
<div class="sidebar">
  <a class="active" href="#home">Home</a>
  <a href="request.php">Student requests</a>
  <a href="admin_issuedbook.php">Issue books</a>
  <a href="admin_view_issue.php">View issued Details</a>
  <a href="AddBook.php">Add Book Details</a>
  <a href="bookedit.php">Edit Book details</a>
   <a href="adminviewbook.php">View/Search book</a>
</div>

<!-- Page content -->
<div class="content">

</div>
</body>
</html>