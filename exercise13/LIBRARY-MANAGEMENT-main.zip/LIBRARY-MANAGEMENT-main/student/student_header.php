<!DOCTYPE html>
<html>
<head>
	<title>Library management system</title>
<link rel="stylesheet" href="../style.css"> 
</head>
<body>
<div class="header">
  <a href="index.php" class="logo">LIBRARY MANAGEMENT SYSTEM</a>
  <div class="header-right">
    <a  href="student.php">Home</a>
     <a  href="student_searchbook.php">Search/view book</a>
      <a  href="student_bookstatus.php">Your Book status</a>
      <a class ="active" href="logout.php">logout</a>
<!--     <a href="register.php">Register</a> -->
  </div>
</div>
</body>
</html>
