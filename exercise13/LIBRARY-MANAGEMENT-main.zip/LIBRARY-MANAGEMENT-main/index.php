<?php 
 include "header1.php";
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style type="text/css">
body 
 {
   background-image: url("image/lib3.jpg");
   
  background-repeat: no-repeat;
   background-size:100%; 
}
 	</style>
 </head>
 <body >
 
 </body>
 </html>