<!DOCTYPE html>
<html>
<head>
	<title>Library management system</title>
<link rel="stylesheet" href="style.css"> 
</head>
<body>
<div class="header">
  <a href="index.php" class="logo">LIBRARY MANAGEMENT SYSTEM</a>
  <div class="header-right">
    <a class="active" href="index.php">Home</a>
    <a href="login1.php">login</a>
    <a href="register.php">Register</a>
  </div>
</div>
</body>
</html>
